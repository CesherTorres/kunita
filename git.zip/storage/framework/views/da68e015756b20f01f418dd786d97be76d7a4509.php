

<?php $__env->startSection('title', 'Detalles'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/detalleColor.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
<div class="offcanvas offcanvas-start sidebar-nav bg-primary" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-body">
        <div class="logo">
            <div class="brand-link d-flex border-bottom justify-content-center align-items-center brand-logo-primary navbar-primary">
                <img src="/images/kunaq-white.png" alt="Logo" class="me-2 my-1" style="width: 8rem;">
            </div>
        </div>
        <div class="user border-bottom">
            <div class="brand-link  brand-logo-primary navbar-primary mx-2 my-3">
                <img src="/public/userAsesor/<?php echo e(Auth::user()->fotouser); ?>" alt="Logo" class="rounded-circle me-2" style="width: 2rem;">
                <span class="brand-text fw-light text-white"><?php echo e(Auth::user()->name); ?></span>
            </div>
        </div>
        <div class="menu">
            <a href="<?php echo e(url('/home')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-grid-1x2-fill me-2 lead"></i> Informe</a>
            <a href="<?php echo e(url('/empresas')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-building me-2 lead"></i> Empresas</a>
            <?php if(Auth::user()->tipousuario_id == '2'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Asesor')): ?>
                    <a href="<?php echo e(url('/publicidad')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-newspaper me-2 lead"></i> Publicidad</a>
                <?php endif; ?>
            <?php else: ?>
                    <a href="<?php echo e(url('/publicidad')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-newspaper me-2 lead"></i> Publicidad</a>
            <?php endif; ?>
            <a href="<?php echo e(url('/productos')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-shop me-2 lead"></i> Productos</a>
            <a href="<?php echo e(url('/categorias')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-bookmarks me-2 lead"></i> Categorías</a>
            <?php if(Auth::user()->tipousuario_id == '2'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Asesor')): ?>
                    <a href="<?php echo e(url('/Asesor')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-people me-2 lead"></i> Asesor</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(url('/Asesor')); ?>" class="btn btn-secondary rounded-pill text-start text-white d-block mx-2 mt-2"><i class="bi bi-people me-2 lead"></i> Asesor</a>
            <?php endif; ?>
            <a href="<?php echo e(url('/solicitudesproductos')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-arrow-down-square me-2 lead"></i> Solicitudes</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-3">
    <div class="container-fluid pt-3">
        <div class="row">
            <div class="col-lg-9">
                <h1 class="text-success fw-bold mb-0 text-uppercase h2"><i class="bi bi-shop me-2"></i> Asesores</h1>
                <p class="text-muted">Se muestran los todos los datos del asesor</p>
            </div>
            <div class="col-lg-3 d-flex">
                
                
                <a href="/Asesor/ReporteI/<?php echo e($asesor->id); ?>" target="_blank" class="btn btn-primary w-100 align-self-center">
                    Descargar
                </a>
            </div>
        </div>
        <div class="">
            <div class="card border-4 borde-top-primary shadow-sm py-2 mb-5">
                
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-4 col-lg-4 order-2 oder-md-1">
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Nombres y Apellidos:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->name); ?></p>
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Identificacion:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->tipodocumento); ?></p>        
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Nº de Identificación:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->ndocumento); ?></p>
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Distrito/Provincia/Departamento:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->ubigeo->distrito.'/'.$asesor->ubigeo->provincia.'/'.$asesor->ubigeo->departamento); ?></p>
    
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-4 order-3 order-md-2">
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Dirección:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->direccion); ?></p>
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Telefono:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->telefono); ?></p>
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Email:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->email); ?></p>
                            </div>
                            <div class="form-group mb-1">               
                                <p class="fw-normal">Estado:</p>
                                <p class="fw-light border-bottom"><?php echo e($asesor->estadouser); ?></p>  
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-4 order-1 order-md-3">
                            <div class="form-group mb-1"> 
                                <img for="uploadImage1" id="uploadPreview1" style="min-height: 330px; max-height: 50px; min-width: 300px; max-width: 50px" src="/public/userAsesor/<?php echo e($asesor->fotouser); ?>" />
                            </div>

                            <div class="text-end">
                                <button type="button" class="btn btn-secondary w-100" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($asesor->id); ?>">
                                    Actualizar contraseña
                                  </button>
                            </div>
                            <?php echo $__env->make('asesor.editpaswword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        
                        
                    </div>
                </div>
            </div>     
            <br> 
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
        
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <?php if(session('info') == 'informacion'): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Ha Ocurrido un Error',
                text: 'Las Contraseñas no coinciden',
            timer: 4000
            })
        </script>
        <?php endif; ?>
   <script>
            // In your Javascript (external .js resource or <script> tag)
            $(document).ready(function() {
                $('.js-example-basic-single').select2();
            });
        </script>
        <script>
            $(function () {
                $('[data-toggle="tooltip"]').tooltip()
            })
        </script>
        <script>
            function previewImage(nb) {        
                var reader = new FileReader();         
                reader.readAsDataURL(document.getElementById('uploadImage'+nb).files[0]);         
                reader.onload = function (e) {             
                    document.getElementById('uploadPreview'+nb).src = e.target.result;         
                };     
            }
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/asesor/show.blade.php ENDPATH**/ ?>