<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>login</title>
    <link rel="icon" href="/images/logo-kunaq.png">
    <link rel="stylesheet" href="sass/custom.css">
    <link rel="stylesheet" href="css/main_store.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
</head>
<body>
    <section>
        <div class="row g-0">
            <div class="col-lg-4 d-flex flex-column align-items-end min-vh-100">
                <div class="text-center pt-lg-5 pb-lg-3 p-4 w-100  align-self-center">
                    <img src="images/LOGO.png" class="img-fluid logo" alt="">
                </div>
                <div class="text-center text-primary py-lg-4 p-4 w-100 align-self-center">
                    <h3 class="fw-bold mb-4">Ingresa a tu cuenta</h3>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                     <?php echo csrf_field(); ?>
                        <div class="mb-4 text-start">
                            <label for="email" class="form-label text-dark fw-bold">Correo Electrónico</label>
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus> 
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-4 text-start">
                            <label for="password" class="form-label text-dark fw-bold">Contraseña</label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <a href="#" id="emailHelp" class="form-text text-muted text-decoration-none">
                                ¿Has olvidado tu contraseña?</a>
                                
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Ingresar</button>
                        </div>
                    </form>
                    

                        <div class="text-center pt-lg-3 pb-lg-4 p-4 w-100 mt-auto">
                            <p class="fw-bold mt-5 text-center text-muted">¿Tienes un negocio? - Únete a nosotros</p>
                        <div class="d-grid gap-2">
                        <a href="<?php echo e(url('/nueva_empresa/create')); ?>" type="button" class=" fw-bold">Registrarme</a>
                    </div>
                      </div>
                      
                    

                </div>
            </div>
            <div class="col-lg-8 d-none d-lg-block">
                <div id="carouselExampleCaptions" class="carousel carousel-dark slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                      <div class="carousel-item active min-vh-100 img-1">
                        <!-- <img src="img-pymes/pyme-1.jpg" class="d-block w-100" alt="..."> -->
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Tienda en linea</h5>
                            <p>Publica tus productos en nuestra marketplace y vende más</p>
                        </div>
                      </div>
                      <div class="carousel-item min-vh-100 img-2">
                        <!-- <img src="img-pymes/pymes-2.jpg" class="d-block w-100" alt="..."> -->
                        <div class="carousel-caption d-none d-md-block">
                          <h5>Haz seguimiento de tus balances</h5>
                          <p>Obtén reportes en tiempo real para tomar mejores decisiones</p>
                        </div>
                      </div>
                      <div class="carousel-item min-vh-100 img-3">
                        <!-- <img src="img-pymes/pymes-3.jpg" class="d-block w-100" alt="..."> -->
                        <div class="carousel-caption d-none d-md-block">
                          <h5>Desde cualquier dispositivo</h5>
                          <p>Accede a la información de tu negocio y ten el control de los procesos</p>
                        </div>
                      </div>
                    </div>
                    
                  </div>
            </div>
        </div>
    </section>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
<!--sweet alert agregar-->
    <?php if(session('addempresapyme') == 'ok'): ?>
        <script>
           Swal.fire(
			'Registro exitoso!',
			'Su empresa a sido registrada, su asesor asignado se comunicará con usted a la brevedad posible para la activación de su cuenta',
			'success'
			)
        </script>
    <?php endif; ?>
</body>
</html>



<?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/auth/login.blade.php ENDPATH**/ ?>