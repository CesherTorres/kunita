

<?php $__env->startSection('title', 'Pedidos'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <!--  extension responsive  -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="/css/footer.css">
    <link rel="stylesheet" type="text/css" href="/css/icons.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
<div class="offcanvas offcanvas-start sidebar-nav bg-primary" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-body">
        <div class="logo">
            <div class="brand-link d-flex border-bottom justify-content-center align-items-center brand-logo-primary navbar-primary">
                <img src="/images/kunaq-mype.png" alt="Logo" class="me-2 my-1" style="width: 14rem;">
            </div>
        </div>
        <div class="user border-bottom">
            <div class="brand-link  brand-logo-primary navbar-primary mx-2 my-3">
                <img src="/public/logos/<?php echo e(Auth::user()->propietario->empresas->logoempresa); ?>" alt="Logo" class="rounded-circle me-2" style="width: 2rem;">
                <span class="brand-text fw-light text-white"><?php echo e(Auth::user()->name); ?></span>
            </div>
        </div>
        <div class="menu">
            <a href="<?php echo e(url('/pyme')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-newspaper me-2 lead"></i> Noticia</a>
            <a href="<?php echo e(url('/perfil')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-building me-2 lead"></i> Perfil</a>
            <a href="<?php echo e(url('/productos_pyme')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-shop me-2 lead"></i> Productos</a>
            <a href="<?php echo e(url('/cobertura')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-truck me-2 lead"></i>Cobertura</a>
            <a href="<?php echo e(url('/pedidos')); ?>" class=" btn btn-secondary rounded-pill text-start text-white d-block mx-2 mt-2"><i class="bi bi-box-seam me-2 lead"></i> Pedidos</a>
            <a href="<?php echo e(url('/ventas')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-cash-coin me-2 lead"></i> Ventas</a>
            <a href="<?php echo e(url('/graficos')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-symmetry-vertical me-2 lead"></i> Graficos</a>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-3">
    <div class="container-fluid pt-3">
        <div class="row">
            <div class="col-lg-9">
                <h1 class="text-success text-uppercase h2 fw-bold mb-0"><i class="bi bi-cash-coin me-2"></i>pedido - <?php echo e($pedido->id); ?></h1>
                <p class="text-muted">Se muestra el detalle del Pedido</p>
            </div>
        </div>
        <div class="card border-4 borde-top-primary shadow-sm py-2 mb-5">
            <div class="card-body">
                
                    <div class="row">
                        <div class=" col-md-4 col-sm-12 form-group"> 
                            <img src="/public/logos/<?php echo e(Auth::user()->propietario->empresas->logoempresa); ?>" style="width:200px; height:auto;" class="mx-auto d-block float-left" alt="...">   
                        </div>
                        <div class=" col-md-4 col-sm-12 text-center text-dark mt-0 mt-md-3 mt-lg-5">
                            <h2 class="text-center"><?php echo e(Auth::user()->propietario->empresas->razonsocial); ?></h2>
                            <p class="">RUC: <?php echo e(Auth::user()->propietario->empresas->ruc); ?></p>
                        </div>
                        <div class=" col-md-4 col-sm-12 form-group text-right">
                            <div class="row">
                                <div class="col-md-6 text-start text-md-end">
                                    <p class="fw-normal">Fecha:</p>
                                </div>
                                <div class="col-md-6 mt-10">
                                    <p class="fw-light"><?php echo e($pedido->created_at); ?></p>     
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 text-start text-md-end">
                                    <p class="fw-normal">Fecha de entrega:</p>
                                </div>
                                <div class="col-md-6 mt-10">
                                    <p class="fw-light"><?php echo e($pedido->fecha_hora); ?></p>     
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr> 
                    <p class="fw-bold">Datos del cliente</p>
                    <div class="row my-2">
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Cliente:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->namecliente); ?></p> 
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Tipo Identificación:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->tipodocumento); ?></p>          
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Nro Identificación:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->ndocumento); ?></p>    
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Telefono:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->celular); ?></p>     
                            </div>
                        </div>
                    </div> 
                    <div class="row mb-5">
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Cobertura:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->cobertura->ubigeos->departamento.'/'.$pedido->cobertura->ubigeos->provincia.'/'.$pedido->cobertura->ubigeos->distrito); ?></p> 
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Dirección:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->direccion); ?></p> 
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Referencia:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->referencia); ?></p> 
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="form-group">               
                                <p class="fw-normal">Correo:</p>
                                <p class="fw-light border-bottom"><?php echo e($pedido->correo); ?></p> 
                            </div>
                        </div>
                    </div>
                    <p class="fw-bold">Detalles de la venta</p>
                    <br>
                    
                    <div class="table-responsive">
                        <table id="detalles" class="table table-sm h-100">
                            <thead class="bg-light">
                                <tr>
                                    <th class="h6">Producto</th>
                                    <th class="h6">Cantidad</th>
                                    <th class="h6">Precio</th>
                                    <th class="h6">SubTotal</th>
                                </tr>
                            </thead>
                                <tbody>
                                    <?php $__currentLoopData = $detallepedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="font-weight-light"><?php echo e($detalle->nameproducto); ?></td>
                                        <td class="font-weight-light"><?php echo e($detalle->cantidad); ?></td>
                                        <td class="font-weight-light"><?php echo e($detalle->precio); ?></td>
                                        <td class="font-weight-light"><?php echo e($detalle->cantidad*$detalle->precio); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>       
                        </table>
                    </div>
                    
                    <br>
                    
                    <div class="text-start">                        
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12">
                                <label for="subtotal" class="form-label text-end fw-light h5">Precio de envio</label>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-12">
                                <h5 class="fw-light" id="total">S/. <?php echo e($pedido->cobertura->precioenvio); ?></h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12">
                                <label for="subtotal" class="form-label text-end fw-light h5">Total de pedido</label>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-12">
                                <h5 class="fw-light" id="total">S/. <?php echo e($pedido->total); ?></h5>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="text-end">                        
                        <div class="row">
                            <div class="col-lg-8 col-md-6 col-sm-12">
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-12">
                                <label for="subtotal" class="form-label text-end fw-bold  h3">Total</label>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-12">
                                <h3 class="fw-bold" id="total">S/. <?php echo e($pedido->total+$pedido->cobertura->precioenvio); ?></h3>
                            </div>
                        </div>
                    </div>
                    
            </div>
            
        </div>
        <form method="post" name="new_purchase" id="new_purchase" action="/pedidos/<?php echo e($pedido->id); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <input type="hidden" name="estado" value="Cerrada">
            <input type="hidden" name="total" value="<?php echo e($pedido->total+$pedido->cobertura->precioenvio); ?>">
            <div class="container form-group text-end pb-5">
                <a class="btn btn-outline-secondary btn-lg" href="<?php echo e(url('/pedidos')); ?>" role="button">Cancelar</a>
                <button type="submit" class="btn btn-primary btn-lg">Cerrar venta</button>
            </div>
        </form>
    
    </div>
    <br>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foterRedes'); ?>
                <li><a href="<?php echo e($redes->propietario->empresas->enlacefacebook); ?>" target="_blank"><i class="fab fa-facebook-f "></i></a></li>
                <li><a href="<?php echo e($redes->propietario->empresas->enlacewhatsapp); ?>" target="_blank"><i class="fab fa-whatsapp "></i></a></li>
                
                <li><a href="<?php echo e($redes->propietario->empresas->enlaceinstagram); ?>" target="_blank"><i class="fab fa-instagram "></i></a></li>
                
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
        
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
            <!-- extension responsive -->
        <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.pyme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/Pedido/edit.blade.php ENDPATH**/ ?>