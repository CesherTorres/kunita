<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kunaq | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="/images/logo-kunaq.png">
    <link rel="stylesheet" href="/sass/custom.css">
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="">
    <div class="d-flex">          
        <?php echo $__env->yieldContent('aside'); ?>
        <div class="w-100">
        <!-- Navbar -->
        <nav class="navbar navbar-light bg-white shadow-sm fixed-top">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div>
                <div class="row">
                    <div class="col">
                        <a class="btn btn-sm btn-outline-primary mx-1 my-1" target="_blank" href="<?php echo e(url('/inicio')); ?>" role="button"><i class="bi bi-shop me-2"></i> Tienda</a>
                    </div>
                    <div class="col">
                        <div class="dropdown mb-2 mb-lg-0">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <!--<img src="/userAsesor/<?php echo e(Auth::user()->fotouser); ?>" alt="Logo" class="rounded-circle me-2" style="width: 1.5rem;">-->
                                    <span class="fw-normal text-dark"><?php echo e(Auth::user()->name); ?></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">Cerrar Sesión</a></li>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </ul>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            </div>
        </nav>
        <!-- Fin Navbar -->

        <div class="bg-light pt-5" id="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    
    <script src="/js/jquery-3.6.0.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/main.js"></script>
    <script src="/js/chart.min.js"></script>
    <script src="/js/validacionesinput.js"></script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/plantilla/principal.blade.php ENDPATH**/ ?>