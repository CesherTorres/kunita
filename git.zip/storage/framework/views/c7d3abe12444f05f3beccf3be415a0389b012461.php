<div class="container">
    <div class="modal fade" id="editcategory<?php echo e($categorias->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Editar Categoría</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if($message = Session::get('errors')): ?>
                    <div class="alert alert-danger">
                        <ul>
                        <p>¡Algo salió mal!</p>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <p class="text-muted text-start">(*) - Campos obligatorios</p>
                <form class="form-group" method="POST" action="/categoriaUpdate/<?php echo e($categorias->id); ?>">      
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Nombre de Categoria(*)</label>
                        <input type="text" name="namecategori" value="<?php echo e($categorias->namecategoria); ?>" class="form-control" required onkeypress="return sololetrasespace(event)" onpaste="return false" maxLength="40">
                    </div>
                    <div class="form-group">
                        <label for="">Descripcion(*)</label>
                        <input type="text" name="descripcion" value="<?php echo e($categorias->descripcion); ?>" class="form-control" required onkeypress="return sololetrasespace(event)" onpaste="return false" maxLength="100">
                    </div>
                    <br>
                    <div class="text-end">
                        <button type="submit" class="btn btn-primary">Actualizar</button>   
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

  <?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/categorias/edit.blade.php ENDPATH**/ ?>