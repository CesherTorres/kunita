

<?php $__env->startSection('title', 'Empresas Asociadas'); ?>

<?php $__env->startSection('content'); ?>

	 <!-- barra de navegacion -->
     <header class="pb-4">
		<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm fixed-top">
			<div class="container">
				<img src="/images/LOGO.png" alt="Logo" class="me-5 my-1" style="width: 10rem;">
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<!--<form action="<?php echo e(route('buscar')); ?>" class="d-flex mt-3 mt-lg-0 col-12 col-md-12 col-lg-6" autocomplete="off">-->
					<!--	<div class="input-group">-->
					<!--		<input class="form-control border border-primary" name="buscarpor" type="search" placeholder="Escribe algo" aria-label="Search">-->
					<!--		<button class="btn btn-primary fw-bold" type="submit"><i class="bi bi-search"></i></button>-->
					<!--	</div>-->
					<!--</form>-->
					<!--<ul class="navbar-nav mb-2 mb-lg-0">-->
					<!--	<li class="nav-item mx-lg-3">-->
					<!--		<button class="btn btn-secondary d-flex fw-bold mt-3 mt-lg-0 text-white" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">Categorías <i class="bi bi-list px-2"></i></button>-->
					<!--	</li>-->
					<!--</ul>-->
	
					<ul class="navbar-nav ms-auto mb-2 mb-lg-0 d-flex  justify-content-center">
						<li class="nav-item me-3">
							<a class="nav-link fw-bolder fs-5" href="<?php echo e(url('/inicio')); ?>">Inicio</a>
						</li>
						<li class="nav-item me-3">
							<a class="nav-link fw-bolder fs-5" href="<?php echo e(url('/empresas-asociadas')); ?>">Tiendas</a>
						</li>
						<li class="nav-item me-3">
							<a class="nav-link fw-bolder fs-5" href="<?php echo e(url('/logueando')); ?>" target="bank"><i class="bi bi-person-fill h4"></i></a>
						</li>
						<!--<li class="nav-item">-->
						<!--	<div class="">-->
						<!--			<a class="btn btn-warning position-relative text-white fw-bold" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" href="<?php echo e(url('/carritoIndex')); ?>"><i class="bi bi-cart-plus-fill h3"></i>-->
						<!--				<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">-->
						<!--					<?php echo e(\Cart::getTotalQuantity()); ?>-->
						<!--				</span>-->
	
						<!--			</a>-->
						<!--			<ul class="dropdown-menu dropdown-menu-lg-end" style="margin: 10px;width: 400px; border-color: #9DA0A2" aria-labelledby="dropdownMenuButton">-->
						<!--					<li><?php echo $__env->make('partials.cart-drop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></li>	-->
						<!--			</ul>-->
						<!--	</div>-->
						<!--</li>-->
					</ul>
				  </div>
			</div>
		</nav>
	</header>
    <!-- fin barra de navegacion -->

	<!-- offcanvas start -->
	<div class="offcanvas offcanvas-start sidebar-nav" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
		<div class="offcanvas-header">
		  <h5 class="offcanvas-title float-center fw-bold" id="offcanvasScrollingLabel">CATEGORIAS</h5>
		  <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
		</div>
		<div class="offcanvas-body px-0">
			<div class="accordion accordion-flush" id="categorias">
				<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="accordion-item">
						<h2 class="accordion-header" id="<?php echo e(str_replace(' ', '',$categoria->namecategoria)); ?>-h">
						<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e(str_replace(' ', '',$categoria->namecategoria)); ?>" aria-expanded="false" aria-controls="Subcategoria">
							<?php echo e($categoria->namecategoria); ?>

						</button>
						</h2>
						<div id="<?php echo e(str_replace(' ', '',$categoria->namecategoria)); ?>" class="accordion-collapse collapse" aria-labelledby="<?php echo e(str_replace(' ', '',$categoria->namecategoria)); ?>-h" data-bs-parent="#categorias">
							<div class="accordion-body px-0 py-0">
								<div class="sub">
									<ul class="navbar-nav ps-3">
										<li>
										<?php $__currentLoopData = $categoria->subcategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<a href="<?php echo e(route('sub.show', $subcategorias)); ?>" class="nav-link my-2" style="cursor-pointer; hover:text-orange capitalize">
												<span class="text-dark fw-lighter"><?php echo e($subcategorias->namesubcategoria); ?></span>
											</a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>          
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	
	</div>
	<!-- offcanvas end -->
	
<img src="/images/banner-company.png" class="img-fluid banner-company py-5" alt="...">
<main class="bg-light main-company container py-5">
    <div class=" text-center text-secondary">
    <i class="bi bi-star h3"></i>
    <i class="bi bi-star h2"></i>
    <i class="bi bi-star h1"></i>
    <i class="bi bi-star h2"></i>
    <i class="bi bi-star h3"></i>
    </div>
    <h2 class="text-center py-2  display-6">Trabajamos con las mejores empresas de la region</h2>        
    <!--<p class="lead text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio quas consequuntur repudiandae voluptatum porro! Ex non voluptatum alias voluptates, exercitationem cupiditate beatae praesentium minus nostrum, provident culpa, corrupti minima commodi.</p>-->

    <div class="row d-flex justify-content-center align-items-center">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-3 col-xl-3 text-center mt-3 my-lg-5">
                <div class="card justify-content-center align-items-center border-0 bg-white rounded shadow">
                    <img src="/public/logos/<?php echo e($producto->logoempresa); ?>" class="rounded-top" style="width: 100%; height: 180px;" alt="">
                    <div class="card-body">
                        <h4 class="text-secondary fw-light"><?php echo e($producto->marca); ?></h4>
						

						<a class="btn btn-primary" href="<?php echo e(route('empre.Asociadas', $producto->slug)); ?>">Ir a la Tienda</a>
						

						<p class="text-dark my-lg-4"><?php echo e($producto->direccion); ?></p>
                        <div class="text-center">
                            <a class="btn btn-primary rounded-circle" target="_bank" href="<?php echo e($producto->enlacefacebook); ?>" role="button"><i class="bi bi-facebook"></i></a>
                            <a class="btn btn-primary rounded-circle" target="_bank" href="<?php echo e($producto->enlaceinstagram); ?>" role="button"><i class="bi bi-instagram"></i></a>
                            <a class="btn btn-primary rounded-circle" target="_bank" href="<?php echo e($producto->enlacewhatsapp); ?>" role="button"><i class="bi bi-whatsapp"></i></a>
                        </div>
                        
                    </div>
                </div>
            </div>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tpsjbkww/comunidadcomercial.kunaq.org.pe/resources/views/empresas/storeempresas.blade.php ENDPATH**/ ?>