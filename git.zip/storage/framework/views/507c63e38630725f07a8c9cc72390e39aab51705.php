

<?php $__env->startSection('title', 'Solicitudes-Productos'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <!--  extension responsive  -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
<div class="offcanvas offcanvas-start sidebar-nav bg-primary" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-body">
        <div class="logo">
            <div class="brand-link d-flex border-bottom justify-content-center align-items-center brand-logo-primary navbar-primary">
                <img src="images/kunaq-white.png" alt="Logo" class="me-2 my-1" style="width: 8rem;">
            </div>
        </div>
        <div class="user border-bottom">
            <div class="brand-link  brand-logo-primary navbar-primary mx-2 my-3">
               <img src="/public/userAsesor/<?php echo e(Auth::user()->fotouser); ?>" alt="Logo" class="rounded-circle me-2" style="width: 2rem;">
                <span class="brand-text fw-light text-white"><?php echo e(Auth::user()->name); ?></span>
            </div>
        </div>
        <div class="menu">
            <a href="<?php echo e(url('/home')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-grid-1x2-fill me-2 lead"></i> Informe</a>
            <a href="<?php echo e(url('/empresa_asesor')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-building me-2 lead"></i> Empresas</a>
            <a href="<?php echo e(url('/productos_asesor')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-shop me-2 lead"></i> Productos</a>
            <a href="<?php echo e(url('/categorias_asesor')); ?>" class="text-white d-block p-3 mx-2"><i class="bi bi-bookmarks me-2 lead"></i> Categorías</a>
            <a class="btn btn-secondary rounded-pill text-start text-white d-block mx-2 mt-2"><i class="bi bi-arrow-down-square me-2 lead"></i> Solicitudes</a>
                <a href="<?php echo e(url('/solicitudesproductos_asesor')); ?>" class="text-secondary d-block fw-bold p-3 mx-4"><i class="bi bi-arrow-down-square me-2"></i> Producto</a>
                <a href="<?php echo e(url('/solicitudesusuarios_asesor')); ?>" class="text-white d-block px-3 py-1 mx-4"><i class="bi bi-arrow-down-square me-2"></i> Usuario</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-3">
    <div class="container-fluid pt-3">
        <div class="row">
            <div class="col-lg-9">
                <h1 class="text-success fw-bold mb-0 text-uppercase h2"><i class="bi bi-arrow-down-square me-2"></i> Solicitudes - Productos</h1>
                <p class="text-muted">Revisar los productos para aprobar o rechazar</p>
            </div>
            <div class="col-lg-3 d-flex">
                
                
            </div>
        </div>
        <div class="card border-4 borde-top-primary shadow-sm py-2 mb-5">
            <div class="card-body">
                <table id="tcompany" class="table table-hover table-sm" cellspacing="0" style="width:100%">
                    <thead class="bg-light">
                        <tr>
                            <th class="h6">Empresa</th>
                            <th class="h6">Producto</th>
                            <th class="h6">Marca</th>
                            <th class="h6">Modelo</th>
                            
                            <th class="h6">Precio</th>
                            <th class="h6">Estado</th>
                            <th class="text-center h6">Accion</th>
                        </tr>
                    </thead>
                    
                        <tbody> 
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="font-weight-light"><?php echo e($producto->razonsocial); ?></td>
                                    <td class="font-weight-light"><?php echo e($producto->nameproducto); ?></td>
                                    <td class="font-weight-light"><?php echo e($producto->marca); ?></td>
                                    <td class="font-weight-light"><?php echo e($producto->modelo); ?></td>
                                    
                                    <td class="font-weight-light"><?php echo e($producto->preciosugerido); ?></td>
                                    <td class="font-weight-light"><?php echo e($producto->estado); ?></td>
                                    <td>                                        
                                        <div class="text-center">
                                            <a href="/solicitudesproductos_asesor/<?php echo e($producto->id); ?>/edit" class="btn btn-outline-info btn-sm"><i class="bi bi-eye"></i> Detalles</a>
                                        </div>      
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>  
                   
                    
                </table>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
        
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
            <!-- extension responsive -->
        <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
        
        <!--datatables-->
        <script>
            $(document).ready(function() {
                $('#tcompany').DataTable({
                    responsive: true,
                    "language": {
                        "lengthMenu": "Mostrar _MENU_ registros",
                        "zeroRecords": "No se encontró nada, lo siento",
                        "info": "Mostrando página _PAGE_ de _PAGES_",
                        "infoEmpty": "No hay registros disponibles",
                        "infoFiltered": "(Filtrado de _MAX_ registros totales)",
                        "search": "Buscar:",
                        "paginate":{
                            "next": "&raquo;",
                            "previous": "&laquo;"
                        } 
                    }
                });
            } );
        </script>

        <!--sweet alert agregar-->
    <?php if(session('solicitud') == 'ok'): ?>
        <script>
            Swal.fire({
            icon: 'success',
            showConfirmButton: false,
            title: 'Solicitud revisada',
            timer: 2000
            })
        </script>
    <?php endif; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gilberto DS\Documents\GitHub\kunita\resources\views/solicitudesproductos_asesor/index.blade.php ENDPATH**/ ?>