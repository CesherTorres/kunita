<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
// use App\Models\User;
// use Illuminate\Support\Facades\Hash;
class AsesorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $asesor = User::create([
        // 'name' => 'Cesar Torres',
        // 'tipodocumento' => 'DNI',
        // 'ndocumento' => '77886644',
        // 'telefono' => '937040520',
        // 'direccion' => 'Av. La Calle',
        // 'email' => 'cesar@mail.com',
        // 'password' => Hash::make('123'),
        // 'fotouser' => 'asesor.png',
        // 'confirmpassword' => Hash::make('123'),
        // 'ubigeo_id' => '100',
        // 'tipousuario_id' => '2',
        // ]);
    }
}
